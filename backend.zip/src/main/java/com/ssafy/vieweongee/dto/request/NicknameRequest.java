package com.ssafy.vieweongee.dto.request;

public class NicknameRequest {
}
