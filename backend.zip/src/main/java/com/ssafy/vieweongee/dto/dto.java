package com.ssafy.vieweongee.dto;

public class dto {
}
