package com.ssafy.vieweongee.model;

public class model {
}
