package com.ssafy.vieweongee.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController("/test")
public class controller {

    public void hi() {
        System.out.println("hhhhhiii");
    }
}
